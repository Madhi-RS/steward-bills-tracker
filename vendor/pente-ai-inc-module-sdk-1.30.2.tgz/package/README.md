# @pente-ai-inc/module-sdk

The Steward module SDK for Node 22.18+ and Next.js: the module contract's types, a signed core
client (`CoreClient`), an event receiver (`EventReceiver`), Web-standard request handlers
(`stewardHandlers`), Steward sign-in for linked modules (`StewardSignIn`), and a fake Steward for
tests (`@pente-ai-inc/module-sdk/testkit`, `FakeCore`). Built ESM with type declarations.

## Install

A private GitHub Package: you need read access to `Pente-AI-Inc/steward-module-sdk` and a GitHub
personal access token (classic) with the `read:packages` scope only, kept in your environment as
`NPM_GITHUB_TOKEN` (never committed). Add to `~/.npmrc` (or your project's `.npmrc`):

```ini
@pente-ai-inc:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${NPM_GITHUB_TOKEN}
```

Then `npm install @pente-ai-inc/module-sdk`. In CI, store the same kind of token as a secret and
give it to npm as `NPM_GITHUB_TOKEN`.

Read the [HANDBOOK](https://github.com/Pente-AI-Inc/steward-module-sdk/blob/main/HANDBOOK.md)
(start from `examples/nextjs-minimal`). Proprietary (UNLICENSED), for Pente's invited module
developers.
